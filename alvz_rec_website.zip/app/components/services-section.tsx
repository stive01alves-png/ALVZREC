
'use client'

import { useInView } from 'react-intersection-observer'
import { motion } from 'framer-motion'
import { Video, Camera, Edit3, Music, Monitor, Zap } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

const services = [
  {
    icon: Music,
    title: 'Clips Musicaux',
    description: 'Création de clips musicaux professionnels avec un style cinématique unique. Du concept à la post-production.',
    features: ['Conception créative', 'Tournage multi-caméras', 'Étalonnage professionnel', 'Effets visuels']
  },
  {
    icon: Camera,
    title: 'Tournages Professionnels',
    description: 'Tournages intérieurs et extérieurs avec équipement haut de gamme. Éclairage cinématique et prises de vue créatives.',
    features: ['Matériel 4K/8K', 'Éclairage pro', 'Équipe expérimentée', 'Locations variées']
  },
  {
    icon: Edit3,
    title: 'Montage & Post-Production',
    description: 'Montage vidéo créatif, étalonnage couleur, effets visuels et sound design pour un rendu professionnel.',
    features: ['Montage créatif', 'Étalonnage couleur', 'Effets visuels', 'Sound design']
  }
]

const additionalServices = [
  { icon: Monitor, title: 'Contenu Digital', description: 'Vidéos pour réseaux sociaux et web' },
  { icon: Video, title: 'Documentaires Courts', description: 'Réalisation de mini-documentaires' },
  { icon: Zap, title: 'Projets Express', description: 'Livraison rapide pour urgences' }
]

export default function ServicesSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  return (
    <section id="services" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4 max-w-6xl">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gradient mb-6">
            Nos Services
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Une expertise complète pour donner vie à vos projets créatifs avec un style visuel percutant et moderne.
          </p>
        </motion.div>

        {/* Services principaux */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: index * 0.2 }}
            >
              <Card className="card-hover bg-card/50 backdrop-blur-sm border-border/50 h-full">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 mx-auto mb-4 bg-primary/10 rounded-full flex items-center justify-center">
                    <service.icon className="w-8 h-8 text-primary" />
                  </div>
                  <CardTitle className="text-xl font-bold text-foreground">
                    {service.title}
                  </CardTitle>
                  <CardDescription className="text-muted-foreground">
                    {service.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center text-sm text-muted-foreground">
                        <div className="w-2 h-2 bg-primary rounded-full mr-3 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Services additionnels */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-center"
        >
          <h3 className="text-2xl font-bold text-foreground mb-8">Services Complémentaires</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {additionalServices.map((service, index) => (
              <div key={service.title} className="flex items-center space-x-4 p-4 bg-card/30 rounded-lg border border-border/30">
                <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center flex-shrink-0">
                  <service.icon className="w-6 h-6 text-accent" />
                </div>
                <div className="text-left">
                  <h4 className="font-semibold text-foreground">{service.title}</h4>
                  <p className="text-sm text-muted-foreground">{service.description}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Process */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="mt-16 text-center"
        >
          <h3 className="text-2xl font-bold text-foreground mb-8">Notre Processus Créatif</h3>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: '01', title: 'Briefing', desc: 'Définition du concept et des objectifs' },
              { step: '02', title: 'Pré-production', desc: 'Planning, casting et préparation' },
              { step: '03', title: 'Tournage', desc: 'Réalisation avec équipe professionnelle' },
              { step: '04', title: 'Post-production', desc: 'Montage, étalonnage et livraison' }
            ].map((phase, index) => (
              <div key={phase.step} className="relative">
                <div className="text-4xl font-bold text-primary/30 mb-2">{phase.step}</div>
                <h4 className="font-semibold text-foreground mb-2">{phase.title}</h4>
                <p className="text-sm text-muted-foreground">{phase.desc}</p>
                {index < 3 && (
                  <div className="hidden md:block absolute top-8 -right-3 w-6 h-0.5 bg-primary/30" />
                )}
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}
