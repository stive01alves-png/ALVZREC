
'use client'

import { useState, useEffect } from 'react'
import { User, Mail, Phone, FileText, DollarSign, Camera } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

interface FormData {
  firstName: string
  lastName: string
  email: string
  phone: string
  service: string
  projectDescription: string
  budget: string
}

interface BookingFormProps {
  initialData: any
  onFormComplete: (formData: any) => void
}

const services = [
  { id: 'clip-essentiel', name: 'Clip Essentiel', price: 800 },
  { id: 'clip-professionnel', name: 'Clip Professionnel', price: 1500 },
  { id: 'clip-premium', name: 'Clip Premium', price: 2800 },
  { id: 'montage-simple', name: 'Montage Simple', price: 400 },
  { id: 'tournage-jour', name: 'Tournage Journée', price: 600 },
  { id: 'custom', name: 'Projet Sur Mesure', price: 0 }
]

const budgetRanges = [
  'Moins de 1 000€',
  '1 000€ - 2 000€',
  '2 000€ - 4 000€',
  '4 000€ - 8 000€',
  'Plus de 8 000€',
  'À discuter'
]

export default function BookingForm({ initialData, onFormComplete }: BookingFormProps) {
  const [formData, setFormData] = useState<FormData>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    service: '',
    projectDescription: '',
    budget: '',
    ...initialData
  })
  
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  const selectedService = services.find(s => s.id === formData.service)
  const amount = selectedService?.price ? selectedService.price * 0.5 : 0 // Acompte 50%

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.firstName?.trim()) {
      newErrors.firstName = 'Le prénom est requis'
    }

    if (!formData.lastName?.trim()) {
      newErrors.lastName = 'Le nom est requis'
    }

    if (!formData.email?.trim()) {
      newErrors.email = 'L\'email est requis'
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Format email invalide'
    }

    if (!formData.phone?.trim()) {
      newErrors.phone = 'Le téléphone est requis'
    } else if (!/^[+]?[\d\s-()]{10,}$/.test(formData.phone)) {
      newErrors.phone = 'Format téléphone invalide'
    }

    if (!formData.service) {
      newErrors.service = 'Veuillez sélectionner un service'
    }

    if (!formData.projectDescription?.trim() || formData.projectDescription.length < 20) {
      newErrors.projectDescription = 'Description requise (minimum 20 caractères)'
    }

    if (!formData.budget) {
      newErrors.budget = 'Veuillez indiquer votre budget'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!validateForm()) return

    setIsSubmitting(true)
    
    try {
      // Simuler l'envoi des données
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      onFormComplete({
        ...formData,
        amount,
        service: selectedService?.name || formData.service
      })
    } catch (error) {
      console.error('Erreur lors de l\'envoi du formulaire:', error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev: FormData) => ({ ...prev, [field]: value }))
    
    // Supprimer l'erreur quand l'utilisateur corrige
    if (errors[field]) {
      setErrors((prev: Record<string, string>) => ({ ...prev, [field]: '' }))
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card className="bg-card/30 border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <User className="w-5 h-5 text-primary" />
            <span>Informations personnelles</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="firstName">Prénom *</Label>
            <div className="relative">
              <Input
                id="firstName"
                value={formData.firstName || ''}
                onChange={(e) => handleInputChange('firstName', e.target.value)}
                className={`pl-10 ${errors.firstName ? 'border-destructive' : 'border-border/50'}`}
                placeholder="Votre prénom"
              />
              <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            </div>
            {errors.firstName && (
              <p className="text-sm text-destructive">{errors.firstName}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="lastName">Nom *</Label>
            <div className="relative">
              <Input
                id="lastName"
                value={formData.lastName || ''}
                onChange={(e) => handleInputChange('lastName', e.target.value)}
                className={`pl-10 ${errors.lastName ? 'border-destructive' : 'border-border/50'}`}
                placeholder="Votre nom"
              />
              <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            </div>
            {errors.lastName && (
              <p className="text-sm text-destructive">{errors.lastName}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email *</Label>
            <div className="relative">
              <Input
                id="email"
                type="email"
                value={formData.email || ''}
                onChange={(e) => handleInputChange('email', e.target.value)}
                className={`pl-10 ${errors.email ? 'border-destructive' : 'border-border/50'}`}
                placeholder="votre@email.com"
              />
              <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            </div>
            {errors.email && (
              <p className="text-sm text-destructive">{errors.email}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Téléphone *</Label>
            <div className="relative">
              <Input
                id="phone"
                value={formData.phone || ''}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                className={`pl-10 ${errors.phone ? 'border-destructive' : 'border-border/50'}`}
                placeholder="06 12 34 56 78"
              />
              <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            </div>
            {errors.phone && (
              <p className="text-sm text-destructive">{errors.phone}</p>
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-card/30 border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Camera className="w-5 h-5 text-accent" />
            <span>Détails du projet</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="service">Service souhaité *</Label>
            <Select value={formData.service || ''} onValueChange={(value) => handleInputChange('service', value)}>
              <SelectTrigger className={`${errors.service ? 'border-destructive' : 'border-border/50'}`}>
                <SelectValue placeholder="Choisissez un service" />
              </SelectTrigger>
              <SelectContent>
                {services.map((service) => (
                  <SelectItem key={service.id} value={service.id}>
                    {service.name} {service.price > 0 && `(${service.price}€)`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.service && (
              <p className="text-sm text-destructive">{errors.service}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="budget">Budget estimé *</Label>
            <Select value={formData.budget || ''} onValueChange={(value) => handleInputChange('budget', value)}>
              <SelectTrigger className={`${errors.budget ? 'border-destructive' : 'border-border/50'}`}>
                <SelectValue placeholder="Sélectionnez votre budget" />
              </SelectTrigger>
              <SelectContent>
                {budgetRanges.map((range) => (
                  <SelectItem key={range} value={range}>
                    {range}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.budget && (
              <p className="text-sm text-destructive">{errors.budget}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="projectDescription">Description du projet *</Label>
            <Textarea
              id="projectDescription"
              value={formData.projectDescription || ''}
              onChange={(e) => handleInputChange('projectDescription', e.target.value)}
              className={`min-h-[120px] resize-none ${errors.projectDescription ? 'border-destructive' : 'border-border/50'}`}
              placeholder="Décrivez votre vision, le style souhaité, les lieux de tournage, le nombre de personnes à filmer, etc. Plus vous êtes précis, mieux nous pourrons vous conseiller."
            />
            <div className="flex justify-between items-center">
              {errors.projectDescription && (
                <p className="text-sm text-destructive">{errors.projectDescription}</p>
              )}
              <p className="text-sm text-muted-foreground ml-auto">
                {formData.projectDescription?.length || 0} caractères (minimum 20)
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Récapitulatif */}
      {selectedService && (
        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-foreground">Récapitulatif</h3>
              <DollarSign className="w-5 h-5 text-primary" />
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Service sélectionné :</span>
                <span className="text-foreground font-medium">{selectedService.name}</span>
              </div>
              {selectedService.price > 0 && (
                <>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Prix total :</span>
                    <span className="text-foreground">{selectedService.price}€</span>
                  </div>
                  <div className="flex justify-between border-t border-border/30 pt-2 font-semibold">
                    <span className="text-muted-foreground">Acompte à verser (50%) :</span>
                    <span className="text-primary text-lg">{amount}€</span>
                  </div>
                </>
              )}
            </div>
            {selectedService.id === 'custom' && (
              <p className="text-sm text-muted-foreground mt-3 p-3 bg-muted/20 rounded-lg">
                Pour les projets sur mesure, nous établirons un devis personnalisé après étude de votre demande.
              </p>
            )}
          </CardContent>
        </Card>
      )}

      <div className="flex justify-center">
        <Button
          type="submit"
          disabled={isSubmitting}
          className="btn-primary text-background font-semibold px-8"
          size="lg"
        >
          {isSubmitting ? 'Traitement...' : 'Continuer vers le paiement'}
        </Button>
      </div>
    </form>
  )
}
