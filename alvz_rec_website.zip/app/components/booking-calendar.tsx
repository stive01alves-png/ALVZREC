
'use client'

import { useState, useEffect } from 'react'
import { Calendar, ChevronLeft, ChevronRight, Clock } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

interface BookingCalendarProps {
  onDateTimeSelect: (date: Date, timeSlot: string) => void
}

const timeSlots = {
  weekday: ['20:00', '21:00'], // Après 20h en semaine
  weekend: ['10:00', '14:00', '16:00', '18:00'] // Week-ends
}

export default function BookingCalendar({ onDateTimeSelect }: BookingCalendarProps) {
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('')
  const [currentMonth, setCurrentMonth] = useState(new Date())
  const [availableDates, setAvailableDates] = useState<Date[]>([])

  useEffect(() => {
    generateAvailableDates()
  }, [currentMonth])

  const generateAvailableDates = () => {
    const dates: Date[] = []
    const startOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1)
    const endOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    for (let date = new Date(startOfMonth); date <= endOfMonth; date.setDate(date.getDate() + 1)) {
      const dayOfWeek = date.getDay()
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6 // Dimanche ou Samedi
      const isWeekday = dayOfWeek >= 1 && dayOfWeek <= 5 // Lundi à Vendredi
      const isFutureDate = date >= today

      if (isFutureDate && (isWeekend || isWeekday)) {
        dates.push(new Date(date))
      }
    }
    
    setAvailableDates(dates)
  }

  const getDaysInMonth = () => {
    const startOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1)
    const endOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0)
    const startOfWeek = new Date(startOfMonth)
    startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay() + 1) // Commencer le lundi

    const days: Date[] = []
    const current = new Date(startOfWeek)

    while (current <= endOfMonth || days.length % 7 !== 0) {
      days.push(new Date(current))
      current.setDate(current.getDate() + 1)
    }

    return days
  }

  const isDateAvailable = (date: Date) => {
    return availableDates.some(availableDate => 
      availableDate.toDateString() === date.toDateString()
    )
  }

  const isDateInCurrentMonth = (date: Date) => {
    return date.getMonth() === currentMonth.getMonth()
  }

  const getAvailableTimeSlotsForDate = (date: Date) => {
    const dayOfWeek = date.getDay()
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6
    return isWeekend ? timeSlots.weekend : timeSlots.weekday
  }

  const handleDateSelect = (date: Date) => {
    if (!isDateAvailable(date)) return
    setSelectedDate(date)
    setSelectedTimeSlot('') // Reset time slot when date changes
  }

  const handleTimeSlotSelect = (timeSlot: string) => {
    setSelectedTimeSlot(timeSlot)
  }

  const handleConfirm = () => {
    if (selectedDate && selectedTimeSlot) {
      onDateTimeSelect(selectedDate, selectedTimeSlot)
    }
  }

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentMonth(prev => {
      const newMonth = new Date(prev)
      if (direction === 'prev') {
        newMonth.setMonth(newMonth.getMonth() - 1)
      } else {
        newMonth.setMonth(newMonth.getMonth() + 1)
      }
      return newMonth
    })
    setSelectedDate(null)
    setSelectedTimeSlot('')
  }

  const days = getDaysInMonth()
  const weekDays = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim']

  return (
    <div className="space-y-8">
      {/* Calendrier */}
      <Card className="bg-card/30 border-border/50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-primary" />
              <span>Choisir une date</span>
            </CardTitle>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigateMonth('prev')}
                className="border-border/50"
              >
                <ChevronLeft size={16} />
              </Button>
              <span className="text-sm font-semibold min-w-[120px] text-center">
                {currentMonth.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigateMonth('next')}
                className="border-border/50"
              >
                <ChevronRight size={16} />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-1 mb-4">
            {weekDays.map(day => (
              <div key={day} className="text-center text-sm text-muted-foreground font-medium p-2">
                {day}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {days.map((date, index) => {
              const isAvailable = isDateAvailable(date)
              const isCurrentMonth = isDateInCurrentMonth(date)
              const isSelected = selectedDate?.toDateString() === date.toDateString()

              return (
                <button
                  key={index}
                  onClick={() => handleDateSelect(date)}
                  disabled={!isAvailable || !isCurrentMonth}
                  className={`
                    aspect-square p-2 text-sm rounded-lg transition-all duration-200
                    ${!isCurrentMonth 
                      ? 'text-muted-foreground/30' 
                      : isSelected 
                        ? 'bg-primary text-background font-semibold shadow-lg' 
                        : isAvailable 
                          ? 'text-foreground hover:bg-primary/20 hover:text-primary border border-border/30' 
                          : 'text-muted-foreground/50 cursor-not-allowed'
                    }
                  `}
                >
                  {date.getDate()}
                </button>
              )
            })}
          </div>
          
          <div className="mt-6 grid grid-cols-2 gap-4 text-xs">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-accent rounded" />
              <span className="text-muted-foreground">Week-ends (10h-18h)</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-primary rounded" />
              <span className="text-muted-foreground">Semaine (après 20h)</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Créneaux horaires */}
      {selectedDate && (
        <Card className="bg-card/30 border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="w-5 h-5 text-accent" />
              <span>Choisir un créneau</span>
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              {selectedDate.toLocaleDateString('fr-FR', { 
                weekday: 'long', 
                day: 'numeric', 
                month: 'long', 
                year: 'numeric' 
              })}
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {getAvailableTimeSlotsForDate(selectedDate).map((timeSlot) => (
                <button
                  key={timeSlot}
                  onClick={() => handleTimeSlotSelect(timeSlot)}
                  className={`
                    p-3 text-sm font-medium rounded-lg border transition-all duration-200
                    ${selectedTimeSlot === timeSlot
                      ? 'bg-accent text-background border-accent shadow-lg'
                      : 'text-foreground border-border/50 hover:bg-accent/20 hover:border-accent hover:text-accent'
                    }
                  `}
                >
                  {timeSlot}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Confirmation */}
      {selectedDate && selectedTimeSlot && (
        <div className="text-center">
          <div className="bg-primary/10 rounded-lg p-6 border border-primary/20 mb-6">
            <h3 className="font-semibold text-foreground mb-2">Créneau sélectionné</h3>
            <p className="text-sm text-muted-foreground">
              <span className="text-primary font-medium">
                {selectedDate.toLocaleDateString('fr-FR', { 
                  weekday: 'long', 
                  day: 'numeric', 
                  month: 'long', 
                  year: 'numeric' 
                })}
              </span>
              {' '}à{' '}
              <span className="text-accent font-medium">{selectedTimeSlot}</span>
            </p>
          </div>
          <Button 
            onClick={handleConfirm}
            className="btn-primary text-background font-semibold px-8"
            size="lg"
          >
            Continuer vers les détails
          </Button>
        </div>
      )}
    </div>
  )
}
