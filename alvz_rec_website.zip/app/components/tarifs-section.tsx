
'use client'

import { useInView } from 'react-intersection-observer'
import { motion } from 'framer-motion'
import { Check, Star, Zap, Crown } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const pricingPlans = [
  {
    name: 'Essentiel',
    icon: Zap,
    price: '800',
    duration: 'à partir de',
    description: 'Parfait pour débuter avec un clip simple et efficace',
    features: [
      'Clip de 1-2 minutes',
      'Tournage demi-journée',
      '1 lieu de tournage',
      'Montage standard',
      'Étalonnage de base',
      '2 révisions incluses',
      'Livraison sous 10 jours'
    ],
    popular: false,
    color: 'accent'
  },
  {
    name: 'Professionnel',
    icon: Star,
    price: '1500',
    duration: 'à partir de',
    description: 'Le choix populaire pour un résultat professionnel complet',
    features: [
      'Clip de 2-4 minutes',
      'Tournage journée complète',
      '2-3 lieux de tournage',
      'Montage créatif avancé',
      'Étalonnage professionnel',
      'Effets visuels simples',
      '5 révisions incluses',
      'Livraison sous 14 jours',
      'Teaser 30s inclus'
    ],
    popular: true,
    color: 'primary'
  },
  {
    name: 'Premium',
    icon: Crown,
    price: '2800',
    duration: 'à partir de',
    description: 'Pour une production haut de gamme avec tous les extras',
    features: [
      'Clip de 3-6 minutes',
      'Tournage sur 2 jours',
      'Lieux multiples illimités',
      'Montage cinématique',
      'Étalonnage professionnel',
      'Effets visuels avancés',
      'Révisions illimitées',
      'Livraison sous 21 jours',
      'Teaser + behind-the-scenes',
      'Formats réseaux sociaux',
      'Musique originale'
    ],
    popular: false,
    color: 'accent'
  }
]

const additionalServices = [
  { service: 'Journée de tournage supplémentaire', price: '400€' },
  { service: 'Lieu de tournage additionnel', price: '150€' },
  { service: 'Acteur/figurant professionnel', price: '200€/jour' },
  { service: 'Drone avec pilote certifié', price: '300€' },
  { service: 'Révision urgente (24h)', price: '200€' },
  { service: 'Version longue (6+ minutes)', price: '500€' }
]

export default function TarifsSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  const scrollToReservation = () => {
    const element = document.getElementById('reservation')
    element?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <section id="tarifs" className="py-20 bg-background">
      <div className="container mx-auto px-4 max-w-7xl">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gradient mb-6">
            Nos Tarifs
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Des formules transparentes adaptées à tous les budgets. Paiement sécurisé avec acompte de 50% à la réservation.
          </p>
        </motion.div>

        {/* Plans tarifaires */}
        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {pricingPlans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className="relative"
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-primary text-background px-4 py-1 rounded-full text-sm font-semibold">
                    Plus populaire
                  </div>
                </div>
              )}
              
              <Card className={`card-hover h-full ${plan.popular ? 'border-primary shadow-xl glow-effect' : 'border-border/50'} bg-card/50 backdrop-blur-sm`}>
                <CardHeader className="text-center pb-8">
                  <div className={`w-16 h-16 mx-auto mb-4 bg-${plan.color}/10 rounded-full flex items-center justify-center`}>
                    <plan.icon className={`w-8 h-8 text-${plan.color}`} />
                  </div>
                  <CardTitle className="text-2xl font-bold text-foreground">
                    {plan.name}
                  </CardTitle>
                  <div className="text-4xl font-bold text-primary mb-2">
                    {plan.price}€
                    <span className="text-lg text-muted-foreground font-normal">/{plan.duration}</span>
                  </div>
                  <CardDescription className="text-muted-foreground">
                    {plan.description}
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-6">
                  <ul className="space-y-3">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start">
                        <Check className={`w-5 h-5 text-${plan.color} mr-3 mt-0.5 flex-shrink-0`} />
                        <span className="text-sm text-muted-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button
                    onClick={scrollToReservation}
                    className={`w-full ${plan.popular ? 'btn-primary text-background' : 'bg-secondary text-foreground hover:bg-secondary/80'} font-semibold`}
                  >
                    Choisir {plan.name}
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Services additionnels */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-center"
        >
          <h3 className="text-2xl font-bold text-foreground mb-8">Services Additionnels</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-4xl mx-auto">
            {additionalServices.map((item, index) => (
              <div key={index} className="flex justify-between items-center p-4 bg-muted/20 rounded-lg border border-border/30">
                <span className="text-sm text-foreground">{item.service}</span>
                <span className="text-sm font-semibold text-primary">{item.price}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Informations complémentaires */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="mt-16 text-center bg-muted/20 rounded-2xl p-8"
        >
          <h3 className="text-xl font-bold text-foreground mb-4">Informations Importantes</h3>
          <div className="grid md:grid-cols-3 gap-6 text-sm text-muted-foreground">
            <div>
              <strong className="text-foreground">Paiement :</strong><br />
              50% à la réservation<br />
              50% à la livraison
            </div>
            <div>
              <strong className="text-foreground">Moyens de paiement :</strong><br />
              Carte bancaire<br />
              PayPal • Virement
            </div>
            <div>
              <strong className="text-foreground">Garanties :</strong><br />
              Satisfait ou remboursé<br />
              Support client 7j/7
            </div>
          </div>
          
          <div className="mt-6 p-4 bg-primary/10 rounded-lg border border-primary/20">
            <p className="text-sm text-foreground">
              <strong>Offre spéciale :</strong> -10% sur votre premier projet avec le code <span className="text-primary font-mono">ALVZ2024</span>
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
