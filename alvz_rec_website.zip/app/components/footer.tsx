
'use client'

import { Instagram, Mail, MapPin, Calendar } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    element?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <footer className="bg-card/50 border-t border-border/50">
      <div className="container mx-auto px-4 max-w-6xl py-16">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Logo et description */}
          <div className="lg:col-span-2 space-y-6">
            <div>
              <h3 className="text-3xl font-bold text-gradient mb-4">ALVZ.REC</h3>
              <p className="text-muted-foreground max-w-md">
                Production de clips musicaux et vidéos créatives à Paris. 
                Style cinématique moderne pour donner vie à vos projets les plus ambitieux.
              </p>
            </div>

            {/* Contact rapide */}
            <div className="space-y-3">
              <div className="flex items-center space-x-3 text-sm">
                <Mail className="w-4 h-4 text-primary flex-shrink-0" />
                <a 
                  href="mailto:alvzrec5@gmail.com" 
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  alvzrec5@gmail.com
                </a>
              </div>
              <div className="flex items-center space-x-3 text-sm">
                <MapPin className="w-4 h-4 text-primary flex-shrink-0" />
                <span className="text-muted-foreground">Paris, France</span>
              </div>
              <div className="flex items-center space-x-3 text-sm">
                <Instagram className="w-4 h-4 text-primary flex-shrink-0" />
                <a 
                  href="https://instagram.com/alvz.rec" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  @alvz.rec
                </a>
              </div>
            </div>
          </div>

          {/* Navigation rapide */}
          <div className="space-y-6">
            <h4 className="font-semibold text-foreground">Navigation</h4>
            <nav className="space-y-3">
              <button
                onClick={() => scrollToSection('services')}
                className="block text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                Services
              </button>
              <button
                onClick={() => scrollToSection('tarifs')}
                className="block text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                Tarifs
              </button>
              <button
                onClick={() => scrollToSection('portfolio')}
                className="block text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                Portfolio
              </button>
              <button
                onClick={() => scrollToSection('contact')}
                className="block text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                Contact
              </button>
            </nav>
          </div>

          {/* CTA */}
          <div className="space-y-6">
            <h4 className="font-semibold text-foreground">Prêt à commencer ?</h4>
            <p className="text-sm text-muted-foreground">
              Réservez votre créneau dès maintenant et concrétisons votre vision créative ensemble.
            </p>
            <Button
              onClick={() => scrollToSection('reservation')}
              className="btn-primary text-background font-semibold w-full"
            >
              <Calendar className="w-4 h-4 mr-2" />
              Réserver maintenant
            </Button>
          </div>
        </div>

        {/* Séparateur */}
        <div className="border-t border-border/30 mt-12 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <div className="text-sm text-muted-foreground">
              © 2024 ALVZ.REC. Tous droits réservés.
            </div>
            
            {/* Réseaux sociaux */}
            <div className="flex items-center space-x-4">
              <span className="text-sm text-muted-foreground">Suivez-nous :</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => window.open('https://instagram.com/alvz.rec', '_blank')}
                className="text-muted-foreground hover:text-primary"
              >
                <Instagram size={16} />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
