
'use client'

import { useState } from 'react'
import { useInView } from 'react-intersection-observer'
import { motion } from 'framer-motion'
import { Play, ExternalLink, Music, Video, Camera, Film, Eye } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

// Données temporaires pour la structure (à remplacer par de vraies vidéos plus tard)
const portfolioItems = [
  {
    id: 1,
    title: 'Clip Musical - Artiste Émergent',
    category: 'clips',
    thumbnail: '/api/placeholder/400/300',
    videoUrl: '#',
    description: 'Clip musical créatif avec effets visuels modernes et étalonnage cinématique.',
    tags: ['Hip-Hop', 'Urbain', 'Studio'],
    duration: '3:24',
    year: '2024'
  },
  {
    id: 2,
    title: 'Court-métrage Corporate',
    category: 'corporate',
    thumbnail: '/api/placeholder/400/300',
    videoUrl: '#',
    description: 'Vidéo corporate moderne pour présentation d\'entreprise avec drone et interviews.',
    tags: ['Corporate', 'Interview', 'Drone'],
    duration: '5:12',
    year: '2024'
  },
  {
    id: 3,
    title: 'Documentaire Musical',
    category: 'documentaire',
    thumbnail: '/api/placeholder/400/300',
    videoUrl: '#',
    description: 'Mini-documentaire sur la scène musicale parisienne underground.',
    tags: ['Documentaire', 'Musique', 'Paris'],
    duration: '8:45',
    year: '2023'
  },
  {
    id: 4,
    title: 'Clip Expérimental',
    category: 'clips',
    thumbnail: '/api/placeholder/400/300',
    videoUrl: '#',
    description: 'Approche artistique expérimentale avec jeu de lumières et mouvements de caméra.',
    tags: ['Expérimental', 'Artistique', 'Lumières'],
    duration: '4:16',
    year: '2024'
  },
  {
    id: 5,
    title: 'Événement Live',
    category: 'events',
    thumbnail: '/api/placeholder/400/300',
    videoUrl: '#',
    description: 'Captation d\'événement musical avec multi-caméras et son live.',
    tags: ['Live', 'Événement', 'Multi-cam'],
    duration: '15:30',
    year: '2023'
  },
  {
    id: 6,
    title: 'Teaser Créatif',
    category: 'teasers',
    thumbnail: '/api/placeholder/400/300',
    videoUrl: '#',
    description: 'Teaser promotionnel court avec motion design et effets dynamiques.',
    tags: ['Teaser', 'Motion Design', 'Promo'],
    duration: '0:30',
    year: '2024'
  }
]

const categories = [
  { id: 'all', name: 'Tout voir', icon: Eye },
  { id: 'clips', name: 'Clips Musicaux', icon: Music },
  { id: 'corporate', name: 'Corporate', icon: Video },
  { id: 'documentaire', name: 'Documentaires', icon: Film },
  { id: 'events', name: 'Événements', icon: Camera },
  { id: 'teasers', name: 'Teasers', icon: Play }
]

export default function PortfolioSection() {
  const [activeCategory, setActiveCategory] = useState('all')
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  const filteredItems = activeCategory === 'all' 
    ? portfolioItems 
    : portfolioItems.filter(item => item.category === activeCategory)

  const scrollToContact = () => {
    const element = document.getElementById('contact')
    element?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <section id="portfolio" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4 max-w-7xl">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gradient mb-6">
            Portfolio
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Découvrez nos créations récentes et l'étendue de notre expertise créative. Chaque projet reflète notre passion pour l'excellence visuelle.
          </p>
        </motion.div>

        {/* Filtres de catégories */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex flex-wrap justify-center gap-4 mb-12"
        >
          {categories.map((category, index) => (
            <motion.button
              key={category.id}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
              onClick={() => setActiveCategory(category.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-full border transition-all duration-300 ${
                activeCategory === category.id
                  ? 'bg-primary text-background border-primary shadow-lg'
                  : 'bg-card/50 text-muted-foreground border-border/50 hover:border-primary hover:text-primary'
              }`}
            >
              <category.icon size={16} />
              <span className="text-sm font-medium">{category.name}</span>
            </motion.button>
          ))}
        </motion.div>

        {/* Message temporaire pour portfolio vide */}
        {portfolioItems.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-center py-16"
          >
            <div className="w-24 h-24 mx-auto mb-6 bg-primary/10 rounded-full flex items-center justify-center">
              <Video className="w-12 h-12 text-primary" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-4">Portfolio en Construction</h3>
            <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
              Nos créations les plus récentes arrivent bientôt ! En attendant, n'hésitez pas à nous contacter pour découvrir nos travaux précédents et discuter de votre projet.
            </p>
            <Button onClick={scrollToContact} className="btn-primary text-background font-semibold">
              Nous contacter
            </Button>
          </motion.div>
        )}

        {/* Grille du portfolio */}
        {filteredItems.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {filteredItems.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: 0.5 + index * 0.1 }}
              >
                <Card className="card-hover bg-card/50 backdrop-blur-sm border-border/50 overflow-hidden group">
                  {/* Thumbnail avec overlay */}
                  <div className="relative aspect-video bg-muted overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300">
                      <div className="bg-primary/90 rounded-full p-4 transform group-hover:scale-110 transition-transform duration-300">
                        <Play className="w-6 h-6 text-background" />
                      </div>
                    </div>
                    
                    {/* Informations overlay */}
                    <div className="absolute bottom-4 left-4 right-4">
                      <div className="flex justify-between items-end">
                        <div>
                          <h3 className="text-white font-semibold text-sm mb-1">{item.title}</h3>
                          <div className="flex items-center space-x-2 text-xs text-white/80">
                            <span>{item.duration}</span>
                            <span>•</span>
                            <span>{item.year}</span>
                          </div>
                        </div>
                        <Button
                          size="sm"
                          variant="secondary"
                          className="bg-white/20 text-white border-white/30 hover:bg-white hover:text-background transition-all duration-300"
                        >
                          <ExternalLink size={14} />
                        </Button>
                      </div>
                    </div>
                  </div>

                  <CardContent className="p-6">
                    <p className="text-muted-foreground text-sm mb-4">
                      {item.description}
                    </p>
                    
                    {/* Tags */}
                    <div className="flex flex-wrap gap-2">
                      {item.tags.map((tag, tagIndex) => (
                        <Badge
                          key={tagIndex}
                          variant="secondary"
                          className="bg-primary/10 text-primary border-primary/20 text-xs"
                        >
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        )}

        {/* CTA pour voir plus ou nous contacter */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="text-center mt-16"
        >
          <div className="bg-card/30 rounded-2xl p-8 border border-border/30">
            <h3 className="text-2xl font-bold text-foreground mb-4">
              Intéressé par nos créations ?
            </h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Chaque projet est unique et conçu sur mesure. Contactez-nous pour discuter de vos idées et voir comment nous pouvons donner vie à votre vision créative.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <Button onClick={scrollToContact} className="btn-primary text-background font-semibold">
                Discuter de votre projet
              </Button>
              <Button 
                onClick={scrollToContact}
                variant="outline" 
                className="border-primary text-primary hover:bg-primary hover:text-background"
              >
                Voir plus d'exemples
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
