
'use client'

import { useState } from 'react'
import { useInView } from 'react-intersection-observer'
import { motion } from 'framer-motion'
import { Mail, Phone, MapPin, Send, MessageCircle, Instagram } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { toast } from 'sonner'

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      toast.error('Veuillez remplir tous les champs')
      return
    }

    setIsSubmitting(true)

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      })

      if (response.ok) {
        toast.success('Message envoyé avec succès ! Nous vous répondrons sous 24h.')
        setFormData({ name: '', email: '', subject: '', message: '' })
      } else {
        throw new Error('Erreur lors de l\'envoi')
      }
    } catch (error) {
      console.error('Erreur contact:', error)
      toast.error('Erreur lors de l\'envoi. Veuillez réessayer.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const contactInfo = [
    {
      icon: Mail,
      title: 'Email',
      value: 'alvzrec5@gmail.com',
      description: 'Réponse sous 24h',
      action: () => window.open('mailto:alvzrec5@gmail.com', '_blank')
    },
    {
      icon: Instagram,
      title: 'Instagram',
      value: '@alvz.rec',
      description: 'Suivez nos créations',
      action: () => window.open('https://instagram.com/alvz.rec', '_blank')
    },
    {
      icon: MapPin,
      title: 'Localisation',
      value: 'Paris, France',
      description: 'Déplacements Île-de-France',
      action: null
    }
  ]

  return (
    <section id="contact" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4 max-w-6xl">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gradient mb-6">
            Nous Contacter
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Une idée de projet ? Une question ? N'hésitez pas à nous contacter. Nous répondons rapidement et sommes toujours ravis de discuter de nouveaux projets créatifs.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-12">
          {/* Informations de contact */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-8"
          >
            <div>
              <h3 className="text-2xl font-bold text-foreground mb-6">Contactez-nous</h3>
              <p className="text-muted-foreground mb-8">
                Nous sommes basés à Paris et intervenons dans toute l'Île-de-France. 
                Réponse garantie sous 24h pour tous vos projets.
              </p>
            </div>

            <div className="space-y-6">
              {contactInfo.map((info, index) => (
                <motion.div
                  key={info.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: 0.3 + index * 0.1 }}
                  className={`flex items-start space-x-4 p-4 bg-card/30 rounded-lg border border-border/30 ${
                    info.action ? 'cursor-pointer hover:border-primary/50 transition-colors' : ''
                  }`}
                  onClick={info.action || undefined}
                >
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <info.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-1">{info.title}</h4>
                    <p className="text-primary font-medium">{info.value}</p>
                    <p className="text-sm text-muted-foreground">{info.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Réseaux sociaux */}
            <div className="pt-6 border-t border-border/30">
              <h4 className="font-semibold text-foreground mb-4">Suivez notre actualité</h4>
              <div className="flex space-x-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => window.open('https://instagram.com/alvz.rec', '_blank')}
                  className="border-border/50 hover:border-primary hover:text-primary"
                >
                  <Instagram size={16} className="mr-2" />
                  Instagram
                </Button>
              </div>
            </div>
          </motion.div>

          {/* Formulaire de contact */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="lg:col-span-2"
          >
            <Card className="bg-card/50 backdrop-blur-sm border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MessageCircle className="w-5 h-5 text-accent" />
                  <span>Formulaire de contact rapide</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="name">Nom complet *</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                        className="border-border/50"
                        placeholder="Votre nom et prénom"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                        className="border-border/50"
                        placeholder="votre@email.com"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="subject">Sujet *</Label>
                    <Input
                      id="subject"
                      value={formData.subject}
                      onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
                      className="border-border/50"
                      placeholder="L'objet de votre message"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Message *</Label>
                    <Textarea
                      id="message"
                      value={formData.message}
                      onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
                      className="min-h-[120px] resize-none border-border/50"
                      placeholder="Décrivez votre projet, vos besoins ou posez votre question..."
                      required
                    />
                  </div>

                  <div className="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0 sm:space-x-4">
                    <p className="text-sm text-muted-foreground">
                      * Champs obligatoires. Réponse sous 24h garantie.
                    </p>
                    
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="btn-primary text-background font-semibold w-full sm:w-auto"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-background/30 border-t-background rounded-full animate-spin mr-2" />
                          Envoi en cours...
                        </>
                      ) : (
                        <>
                          <Send size={16} className="mr-2" />
                          Envoyer le message
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>

            {/* Informations supplémentaires */}
            <div className="grid md:grid-cols-2 gap-6 mt-8">
              <div className="bg-accent/5 rounded-lg p-6 border border-accent/20">
                <h4 className="font-semibold text-foreground mb-2 flex items-center">
                  <Phone className="w-4 h-4 text-accent mr-2" />
                  Rendez-vous téléphonique
                </h4>
                <p className="text-sm text-muted-foreground">
                  Préférez discuter de vive voix ? Demandez un rendez-vous téléphonique 
                  dans votre message et nous vous rappellerons rapidement.
                </p>
              </div>

              <div className="bg-primary/5 rounded-lg p-6 border border-primary/20">
                <h4 className="font-semibold text-foreground mb-2 flex items-center">
                  <MessageCircle className="w-4 h-4 text-primary mr-2" />
                  Devis gratuit
                </h4>
                <p className="text-sm text-muted-foreground">
                  Tous nos devis sont gratuits et personnalisés. Décrivez votre projet 
                  et obtenez une estimation tarifaire détaillée.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
