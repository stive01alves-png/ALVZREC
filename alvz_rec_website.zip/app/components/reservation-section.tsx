
'use client'

import { useState } from 'react'
import { useInView } from 'react-intersection-observer'
import { motion } from 'framer-motion'
import { Calendar, Clock, CreditCard, Shield } from 'lucide-react'
import BookingCalendar from './booking-calendar'
import BookingForm from './booking-form'
import PaymentSection from './payment-section'

type BookingStep = 'calendar' | 'form' | 'payment' | 'confirmation'

interface BookingData {
  date?: Date
  timeSlot?: string
  service?: string
  firstName?: string
  lastName?: string
  email?: string
  phone?: string
  projectDescription?: string
  budget?: string
  amount?: number
}

export default function ReservationSection() {
  const [currentStep, setCurrentStep] = useState<BookingStep>('calendar')
  const [bookingData, setBookingData] = useState<BookingData>({})
  
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  const steps = [
    { id: 'calendar', name: 'Date & Créneau', icon: Calendar, description: 'Choisissez votre créneau' },
    { id: 'form', name: 'Informations', icon: Clock, description: 'Détails du projet' },
    { id: 'payment', name: 'Paiement', icon: CreditCard, description: 'Réservation sécurisée' },
    { id: 'confirmation', name: 'Confirmation', icon: Shield, description: 'C\'est confirmé !' }
  ]

  const getCurrentStepIndex = () => {
    return steps.findIndex(step => step.id === currentStep)
  }

  const handleStepComplete = (stepData: Partial<BookingData>) => {
    setBookingData(prev => ({ ...prev, ...stepData }))
    
    // Passer à l'étape suivante
    const currentIndex = getCurrentStepIndex()
    if (currentIndex < steps.length - 1) {
      setCurrentStep(steps[currentIndex + 1].id as BookingStep)
    }
  }

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 'calendar':
        return (
          <BookingCalendar
            onDateTimeSelect={(date, timeSlot) => {
              handleStepComplete({ date, timeSlot })
            }}
          />
        )
      case 'form':
        return (
          <BookingForm
            initialData={bookingData}
            onFormComplete={(formData) => {
              handleStepComplete(formData)
            }}
          />
        )
      case 'payment':
        return (
          <PaymentSection
            bookingData={bookingData}
            onPaymentComplete={(paymentData) => {
              handleStepComplete(paymentData)
            }}
          />
        )
      case 'confirmation':
        return (
          <div className="text-center py-12">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5, type: 'spring' }}
              className="w-24 h-24 mx-auto mb-6 bg-accent/20 rounded-full flex items-center justify-center"
            >
              <Shield className="w-12 h-12 text-accent" />
            </motion.div>
            <h3 className="text-2xl font-bold text-foreground mb-4">
              Réservation Confirmée !
            </h3>
            <p className="text-muted-foreground mb-6 max-w-lg mx-auto">
              Votre réservation a été enregistrée avec succès. Vous recevrez un email de confirmation avec tous les détails.
            </p>
            <div className="bg-card/50 rounded-lg p-6 border border-border/50 max-w-md mx-auto">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Date :</span>
                  <span className="text-foreground">
                    {bookingData.date?.toLocaleDateString('fr-FR', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Créneau :</span>
                  <span className="text-foreground">{bookingData.timeSlot}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Service :</span>
                  <span className="text-foreground">{bookingData.service}</span>
                </div>
                <div className="flex justify-between border-t border-border/50 pt-2 font-semibold">
                  <span className="text-muted-foreground">Acompte versé :</span>
                  <span className="text-primary">{bookingData.amount}€</span>
                </div>
              </div>
            </div>
          </div>
        )
      default:
        return null
    }
  }

  return (
    <section id="reservation" className="py-20 bg-background">
      <div className="container mx-auto px-4 max-w-4xl">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gradient mb-6">
            Réservation
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Réservez votre créneau en quelques clics. Créneaux disponibles les week-ends et après 20h en semaine.
          </p>
        </motion.div>

        {/* Progress Steps */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-12"
        >
          <div className="flex items-center justify-between max-w-2xl mx-auto">
            {steps.map((step, index) => {
              const isActive = step.id === currentStep
              const isCompleted = getCurrentStepIndex() > index
              const isAccessible = getCurrentStepIndex() >= index

              return (
                <div key={step.id} className="flex items-center">
                  <div className="flex flex-col items-center">
                    <div
                      className={`w-12 h-12 rounded-full border-2 flex items-center justify-center transition-all duration-300 ${
                        isCompleted
                          ? 'bg-accent border-accent text-background'
                          : isActive
                          ? 'bg-primary border-primary text-background'
                          : isAccessible
                          ? 'border-primary text-primary'
                          : 'border-muted text-muted-foreground'
                      }`}
                    >
                      <step.icon size={20} />
                    </div>
                    <div className="text-center mt-2">
                      <div className={`text-sm font-semibold ${isActive ? 'text-primary' : 'text-muted-foreground'}`}>
                        {step.name}
                      </div>
                      <div className="text-xs text-muted-foreground hidden sm:block">
                        {step.description}
                      </div>
                    </div>
                  </div>
                  {index < steps.length - 1 && (
                    <div className={`w-16 h-0.5 mx-4 ${isCompleted ? 'bg-accent' : 'bg-muted'} transition-colors duration-300`} />
                  )}
                </div>
              )
            })}
          </div>
        </motion.div>

        {/* Current Step Content */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="bg-card/50 backdrop-blur-sm border border-border/50 rounded-2xl p-8"
        >
          {renderCurrentStep()}
        </motion.div>

        {/* Informations importantes */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-12 text-center"
        >
          <div className="grid md:grid-cols-3 gap-6 text-sm">
            <div className="bg-muted/20 rounded-lg p-4 border border-border/30">
              <Calendar className="w-8 h-8 text-primary mx-auto mb-2" />
              <h4 className="font-semibold text-foreground mb-1">Créneaux disponibles</h4>
              <p className="text-muted-foreground">Week-ends et après 20h en semaine</p>
            </div>
            <div className="bg-muted/20 rounded-lg p-4 border border-border/30">
              <CreditCard className="w-8 h-8 text-accent mx-auto mb-2" />
              <h4 className="font-semibold text-foreground mb-1">Paiement sécurisé</h4>
              <p className="text-muted-foreground">Acompte 50% - Carte bancaire & PayPal</p>
            </div>
            <div className="bg-muted/20 rounded-lg p-4 border border-border/30">
              <Shield className="w-8 h-8 text-primary mx-auto mb-2" />
              <h4 className="font-semibold text-foreground mb-1">Garantie satisfaction</h4>
              <p className="text-muted-foreground">Annulation gratuite sous 48h</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
