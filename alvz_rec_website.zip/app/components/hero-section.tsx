
'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Play, Camera, Video, Star, Calendar } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function HeroSection() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    element?.scrollIntoView({ behavior: 'smooth' })
  }

  if (!mounted) {
    return (
      <section id="accueil" className="relative min-h-screen flex items-center justify-center hero-gradient">
        <div className="container mx-auto px-4 max-w-6xl text-center">
          <div className="space-y-8">
            <h1 className="text-5xl md:text-7xl font-bold text-gradient">
              ALVZ.REC
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto">
              Production de clips musicaux et vidéos créatives à Paris
            </p>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section id="accueil" className="relative min-h-screen flex items-center justify-center hero-gradient overflow-hidden">
      {/* Effet de particules/background */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-2 h-2 bg-primary rounded-full animate-pulse" />
        <div className="absolute top-40 right-32 w-1 h-1 bg-accent rounded-full animate-ping" />
        <div className="absolute bottom-32 left-16 w-3 h-3 bg-primary/50 rounded-full animate-pulse" />
        <div className="absolute bottom-20 right-20 w-1 h-1 bg-accent/70 rounded-full animate-ping" />
      </div>

      <div className="container mx-auto px-4 max-w-6xl text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-8"
        >
          {/* Logo Principal */}
          <motion.h1 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="text-5xl md:text-7xl lg:text-8xl font-bold text-gradient mb-4"
          >
            ALVZ.REC
          </motion.h1>

          {/* Slogan */}
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed"
          >
            Production de <span className="text-primary font-semibold">clips musicaux</span> et 
            <span className="text-accent font-semibold"> vidéos créatives</span> à Paris
          </motion.p>

          {/* Sous-titre */}
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="text-lg text-muted-foreground max-w-2xl mx-auto"
          >
            Style cinématique moderne • Tournages intérieurs & extérieurs • Montage professionnel
          </motion.p>

          {/* Icônes de services */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="flex items-center justify-center space-x-8 my-8"
          >
            <div className="flex items-center space-x-2 text-primary">
              <Video size={24} />
              <span className="hidden sm:block text-sm">Clips</span>
            </div>
            <div className="flex items-center space-x-2 text-accent">
              <Camera size={24} />
              <span className="hidden sm:block text-sm">Tournage</span>
            </div>
            <div className="flex items-center space-x-2 text-primary">
              <Play size={24} />
              <span className="hidden sm:block text-sm">Montage</span>
            </div>
          </motion.div>

          {/* Boutons CTA */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1 }}
            className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6 mt-12"
          >
            <Button
              onClick={() => scrollToSection('reservation')}
              size="lg"
              className="btn-primary text-background font-semibold px-8 py-4 text-lg w-full sm:w-auto"
            >
              <Calendar className="mr-2 h-5 w-5" />
              Réserver un projet
            </Button>
            <Button
              onClick={() => scrollToSection('portfolio')}
              variant="outline"
              size="lg"
              className="border-primary text-primary hover:bg-primary hover:text-background transition-all duration-300 px-8 py-4 text-lg w-full sm:w-auto"
            >
              <Star className="mr-2 h-5 w-5" />
              Voir nos créations
            </Button>
          </motion.div>

          {/* Stats ou badges */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.2 }}
            className="flex items-center justify-center space-x-8 mt-16 text-sm text-muted-foreground"
          >
            <div className="text-center">
              <div className="text-primary font-bold text-xl">100+</div>
              <div>Projets réalisés</div>
            </div>
            <div className="w-px h-12 bg-border"></div>
            <div className="text-center">
              <div className="text-accent font-bold text-xl">Paris</div>
              <div>Base créative</div>
            </div>
            <div className="w-px h-12 bg-border"></div>
            <div className="text-center">
              <div className="text-primary font-bold text-xl">24h</div>
              <div>Réponse rapide</div>
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1.5 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <div className="w-6 h-10 border-2 border-primary rounded-full flex justify-center">
          <div className="w-1 h-3 bg-primary rounded-full mt-2 animate-bounce"></div>
        </div>
      </motion.div>
    </section>
  )
}
