
'use client'

import { useState } from 'react'
import { CreditCard, Shield, CheckCircle, AlertCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import { toast } from 'sonner'

interface PaymentSectionProps {
  bookingData: any
  onPaymentComplete: (paymentData: any) => void
}

const paymentMethods = [
  {
    id: 'card',
    name: 'Carte bancaire',
    description: 'Paiement sécurisé par Stripe',
    icon: CreditCard,
    fees: 0
  },
  {
    id: 'paypal',
    name: 'PayPal',
    description: 'Paiement via PayPal',
    icon: Shield,
    fees: 0
  }
]

export default function PaymentSection({ bookingData, onPaymentComplete }: PaymentSectionProps) {
  const [selectedMethod, setSelectedMethod] = useState('card')
  const [isProcessing, setIsProcessing] = useState(false)
  const [cardDetails, setCardDetails] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardholderName: ''
  })

  const amount = bookingData.amount || 0

  const handlePayment = async () => {
    if (!selectedMethod) {
      toast.error('Veuillez sélectionner un mode de paiement')
      return
    }

    if (selectedMethod === 'card' && (!cardDetails.cardNumber || !cardDetails.expiryDate || !cardDetails.cvv || !cardDetails.cardholderName)) {
      toast.error('Veuillez remplir tous les champs de la carte')
      return
    }

    setIsProcessing(true)

    try {
      // Simuler l'appel à l'API de paiement
      const response = await fetch('/api/booking', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          ...bookingData,
          paymentMethod: selectedMethod,
          cardDetails: selectedMethod === 'card' ? cardDetails : undefined
        })
      })

      if (response.ok) {
        const result = await response.json()
        toast.success('Paiement effectué avec succès!')
        onPaymentComplete({
          paymentId: result.paymentId,
          paymentStatus: 'paid',
          bookingId: result.bookingId
        })
      } else {
        throw new Error('Erreur lors du paiement')
      }
    } catch (error) {
      console.error('Erreur paiement:', error)
      toast.error('Erreur lors du paiement. Veuillez réessayer.')
    } finally {
      setIsProcessing(false)
    }
  }

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '')
    const matches = v.match(/\d{4,16}/g)
    const match = matches && matches[0] || ''
    const parts = []
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4))
    }
    if (parts.length) {
      return parts.join(' ')
    } else {
      return v
    }
  }

  const formatExpiryDate = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '')
    if (v.length >= 2) {
      return v.slice(0, 2) + '/' + v.slice(2, 4)
    }
    return v
  }

  return (
    <div className="space-y-6">
      {/* Récapitulatif de la commande */}
      <Card className="bg-primary/5 border-primary/20">
        <CardHeader>
          <CardTitle className="text-lg text-foreground">Récapitulatif de la réservation</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Date :</span>
            <span className="text-foreground font-medium">
              {bookingData.date?.toLocaleDateString('fr-FR', {
                weekday: 'long',
                day: 'numeric',
                month: 'long',
                year: 'numeric'
              })}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Heure :</span>
            <span className="text-foreground font-medium">{bookingData.timeSlot}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Service :</span>
            <span className="text-foreground font-medium">{bookingData.service}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Client :</span>
            <span className="text-foreground font-medium">
              {bookingData.firstName} {bookingData.lastName}
            </span>
          </div>
          <div className="border-t border-border/30 pt-3">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Acompte à verser (50%) :</span>
              <span className="text-primary font-bold text-xl">{amount}€</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sélection du mode de paiement */}
      <Card className="bg-card/30 border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="w-5 h-5 text-accent" />
            <span>Mode de paiement</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <RadioGroup value={selectedMethod} onValueChange={setSelectedMethod} className="space-y-4">
            {paymentMethods.map((method) => (
              <div key={method.id} className="flex items-center space-x-3 p-4 border border-border/30 rounded-lg hover:border-primary/50 transition-colors">
                <RadioGroupItem value={method.id} id={method.id} />
                <method.icon className="w-5 h-5 text-primary flex-shrink-0" />
                <div className="flex-1">
                  <Label htmlFor={method.id} className="font-semibold text-foreground cursor-pointer">
                    {method.name}
                  </Label>
                  <p className="text-sm text-muted-foreground">{method.description}</p>
                </div>
                {method.fees > 0 && (
                  <span className="text-sm text-muted-foreground">+{method.fees}€</span>
                )}
              </div>
            ))}
          </RadioGroup>
        </CardContent>
      </Card>

      {/* Formulaire de carte bancaire */}
      {selectedMethod === 'card' && (
        <Card className="bg-card/30 border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CreditCard className="w-5 h-5 text-primary" />
              <span>Informations de carte</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="cardholderName">Nom du porteur *</Label>
              <input
                id="cardholderName"
                type="text"
                value={cardDetails.cardholderName}
                onChange={(e) => setCardDetails(prev => ({ ...prev, cardholderName: e.target.value }))}
                className="w-full px-3 py-2 bg-input border border-border/50 rounded-md text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="Nom tel qu'il apparaît sur la carte"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cardNumber">Numéro de carte *</Label>
              <input
                id="cardNumber"
                type="text"
                value={cardDetails.cardNumber}
                onChange={(e) => setCardDetails(prev => ({ ...prev, cardNumber: formatCardNumber(e.target.value) }))}
                className="w-full px-3 py-2 bg-input border border-border/50 rounded-md text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="1234 5678 9012 3456"
                maxLength={19}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="expiryDate">Date d'expiration *</Label>
                <input
                  id="expiryDate"
                  type="text"
                  value={cardDetails.expiryDate}
                  onChange={(e) => setCardDetails(prev => ({ ...prev, expiryDate: formatExpiryDate(e.target.value) }))}
                  className="w-full px-3 py-2 bg-input border border-border/50 rounded-md text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="MM/AA"
                  maxLength={5}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cvv">CVV *</Label>
                <input
                  id="cvv"
                  type="text"
                  value={cardDetails.cvv}
                  onChange={(e) => setCardDetails(prev => ({ ...prev, cvv: e.target.value.replace(/\D/g, '').slice(0, 4) }))}
                  className="w-full px-3 py-2 bg-input border border-border/50 rounded-md text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="123"
                  maxLength={4}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Informations de sécurité */}
      <div className="flex items-start space-x-3 p-4 bg-accent/5 border border-accent/20 rounded-lg">
        <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
        <div className="text-sm">
          <p className="text-foreground font-semibold mb-1">Paiement 100% sécurisé</p>
          <p className="text-muted-foreground">
            Vos données sont cryptées et protégées. Aucune information bancaire n'est stockée sur nos serveurs.
            Vous pouvez annuler gratuitement jusqu'à 48h avant le rendez-vous.
          </p>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4 pt-6">
        <Button
          onClick={handlePayment}
          disabled={isProcessing || !selectedMethod}
          className="btn-primary text-background font-semibold px-8 w-full sm:w-auto"
          size="lg"
        >
          {isProcessing ? (
            <>
              <div className="w-4 h-4 border-2 border-background/30 border-t-background rounded-full animate-spin mr-2" />
              Traitement en cours...
            </>
          ) : (
            <>
              <Shield className="w-4 h-4 mr-2" />
              Finaliser le paiement ({amount}€)
            </>
          )}
        </Button>
      </div>

      {/* Note légale */}
      <p className="text-xs text-muted-foreground text-center">
        En finalisant votre paiement, vous acceptez nos conditions générales de vente et notre politique de confidentialité.
        Le solde restant ({(bookingData.amount || 0) * 1}€) sera à régler le jour du tournage.
      </p>
    </div>
  )
}
