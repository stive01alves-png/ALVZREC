
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { ThemeProvider } from '@/components/theme-provider'
import { Toaster } from 'sonner'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'ALVZ.REC - Production de Clips Musicaux & Vidéos Créatives',
  description: 'ALVZ.REC, votre partenaire créatif à Paris pour la production de clips musicaux, montage vidéo et tournages professionnels. Style cinématique et moderne.',
  keywords: 'clips musicaux, montage vidéo, tournage, production vidéo, Paris, créatif, cinématique',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster 
            position="top-center" 
            theme="dark"
            richColors
            closeButton
          />
        </ThemeProvider>
      </body>
    </html>
  )
}
