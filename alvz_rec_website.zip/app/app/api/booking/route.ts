
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    
    const {
      firstName,
      lastName,
      email,
      phone,
      service,
      projectDescription,
      budget,
      date,
      timeSlot,
      amount,
      paymentMethod
    } = data

    // Validation des données requises
    if (!firstName || !lastName || !email || !phone || !service || !projectDescription || !date || !timeSlot || !amount) {
      return NextResponse.json(
        { error: 'Données manquantes' },
        { status: 400 }
      )
    }

    // Créer la réservation en base
    const booking = await prisma.booking.create({
      data: {
        firstName,
        lastName,
        email,
        phone,
        service,
        projectDescription,
        budget: budget || '',
        date: new Date(date),
        timeSlot,
        amount: parseFloat(amount.toString()),
        status: 'confirmed',
        paymentStatus: 'paid' // Simuler le paiement réussi
      }
    })

    // Simuler un ID de paiement
    const paymentId = `pay_${Math.random().toString(36).substr(2, 9)}`

    return NextResponse.json({
      success: true,
      bookingId: booking.id,
      paymentId,
      message: 'Réservation créée avec succès'
    })

  } catch (error) {
    console.error('Erreur lors de la création de réservation:', error)
    return NextResponse.json(
      { error: 'Erreur serveur lors de la création de réservation' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const bookingId = searchParams.get('id')

    if (!bookingId) {
      return NextResponse.json(
        { error: 'ID de réservation manquant' },
        { status: 400 }
      )
    }

    const booking = await prisma.booking.findUnique({
      where: { id: bookingId }
    })

    if (!booking) {
      return NextResponse.json(
        { error: 'Réservation non trouvée' },
        { status: 404 }
      )
    }

    return NextResponse.json(booking)

  } catch (error) {
    console.error('Erreur lors de la récupération de réservation:', error)
    return NextResponse.json(
      { error: 'Erreur serveur lors de la récupération' },
      { status: 500 }
    )
  }
}
