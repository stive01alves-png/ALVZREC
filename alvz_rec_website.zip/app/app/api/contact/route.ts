
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    
    const { name, email, subject, message } = data

    // Validation des données requises
    if (!name || !email || !subject || !message) {
      return NextResponse.json(
        { error: 'Tous les champs sont obligatoires' },
        { status: 400 }
      )
    }

    // Validation format email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Format email invalide' },
        { status: 400 }
      )
    }

    // Créer le contact en base
    const contact = await prisma.contact.create({
      data: {
        name: name.trim(),
        email: email.trim().toLowerCase(),
        subject: subject.trim(),
        message: message.trim(),
        status: 'new'
      }
    })

    return NextResponse.json({
      success: true,
      contactId: contact.id,
      message: 'Message envoyé avec succès'
    })

  } catch (error) {
    console.error('Erreur lors de l\'envoi du contact:', error)
    return NextResponse.json(
      { error: 'Erreur serveur lors de l\'envoi du message' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    // Route pour récupérer les contacts (admin uniquement)
    const contacts = await prisma.contact.findMany({
      orderBy: {
        createdAt: 'desc'
      },
      take: 50 // Limiter à 50 contacts récents
    })

    return NextResponse.json(contacts)

  } catch (error) {
    console.error('Erreur lors de la récupération des contacts:', error)
    return NextResponse.json(
      { error: 'Erreur serveur lors de la récupération' },
      { status: 500 }
    )
  }
}
