
import HeroSection from '@/components/hero-section'
import ServicesSection from '@/components/services-section'
import TarifsSection from '@/components/tarifs-section'
import PortfolioSection from '@/components/portfolio-section'
import ReservationSection from '@/components/reservation-section'
import ContactSection from '@/components/contact-section'
import Footer from '@/components/footer'
import Header from '@/components/header'

export default function HomePage() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <Header />
      <HeroSection />
      <ServicesSection />
      <TarifsSection />
      <PortfolioSection />
      <ReservationSection />
      <ContactSection />
      <Footer />
    </main>
  )
}
